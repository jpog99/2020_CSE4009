//2019007901
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <math.h>

typedef struct cache_t {
    char valid;
    unsigned long long int tag;
    unsigned long long int lru;
} cache_t;

cache_t** cache;  
int miss= 0,hit= 0,eviction= 0;
unsigned long long int lru_counter = 1;


void fetchData(unsigned long long int addr, int s, int E, int b)
{  
    unsigned long long int mask = (unsigned long long int) (pow(2, s) - 1);
    unsigned long long int index = (addr >> b) & mask;
    unsigned long long int tag = addr >> (s+b);

    cache_t* list_cache = cache[index];
    int i, victim= 0;
    
    //check if address requested is available in cache
    for(i = 0; i < E; i++) {
        if(list_cache[i].tag == tag && list_cache[i].valid == 1) {
                list_cache[i].lru = lru_counter;
                hit++;
                break;
        }
        else if(list_cache[victim].lru > list_cache[i].lru) 
        	victim = i;
    }
    
    //if not exist in cache
    if(i == E) {
        
        if(list_cache[victim].valid == 0) {
            list_cache[victim].valid = 1;
            list_cache[victim].tag = tag;
            list_cache[victim].lru = lru_counter;
        }
        else {
            list_cache[victim].valid = 1;
            list_cache[victim].tag = tag;
            list_cache[victim].lru = lru_counter;
            eviction++;
        }
        miss++;
    }
}

void readTraceFile(char* trace_file, int s, int E, int b)
{
    char read_buffer[1000];
    FILE* file = fopen(trace_file, "r");
    
    //get how many operation (lines in file)
    int operation_cnt = 0;
    while(!feof(file)) {
        fgets(read_buffer,20,file);
        operation_cnt++;
    }

    fclose(file);

    file = fopen(trace_file, "r");
    char string_addr[20]; int j;
    for (int i=0 ; i <= operation_cnt - 2; i++) {
        lru_counter++;
        fgets(read_buffer,20,file);

	//parsing address number from trace file to int
        for(j = 3; j < 20; j++) {
            if(read_buffer[j] != ',') 
                string_addr[j-3] = read_buffer[j];
            
            else break;
        }
        
        string_addr[j-3] = '\0';
        unsigned long long int addr=0;
        sscanf(string_addr, "%llx", &addr);

	//checking operation type, ignoring operation I case
        if(read_buffer[1] == 'M') {
            fetchData(addr,s,E,b);
            fetchData(addr,s,E,b);
        }
        else if(read_buffer[1] == 'L' || read_buffer[1] == 'S') {
            fetchData(addr,s,E,b);
        }
    }
    fclose(file);
}


int main(int argc, char* argv[])
{
    char c;
    int s,b,E;
    char* trace_file;

    while( (c=getopt(argc,argv,"s:E:b:t:vh")) != -1){
        switch(c){
        case 's':
            s = atoi(optarg);
            break;
        case 'E':
            E = atoi(optarg);
            break;
        case 'b':
            b = atoi(optarg);
            break;
        case 't':
            trace_file = optarg;
            break;
        default:
            exit(1);
        }
    }

    if (s == 0 || E == 0 || b == 0 || trace_file == NULL) {
        printf("Missing required command line argument\n");
        exit(1);
    }

    int S = (unsigned int) pow(2, s);
 
    //initialize cache 2d array
    cache = (cache_t**) malloc(sizeof(cache_t*) * S);
    for (int i=0; i<S; i++){
        cache[i]=(cache_t*) malloc(sizeof(cache_t) * E);
        for (int j=0; j<E; j++){
            cache[i][j].valid = 0;
            cache[i][j].tag = 0;
            cache[i][j].lru = 0;
        }
    }

    readTraceFile(trace_file,s,E,b);

    //free cache after done	  
    for (int i=0; i<S; i++)
        free(cache[i]);
    
    free(cache);
    
    printSummary(hit, miss, eviction);
    return 0;
} 
